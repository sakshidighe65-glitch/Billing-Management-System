from django.db import models
from django.utils import timezone

class Customer(models.Model):
    name = models.CharField(max_length=100)   
    contact = models.CharField(max_length=15, unique=True)  
    balance_due = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    loyalty_points = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    total_visits = models.IntegerField(default=0)   
    

    def __str__(self):
        return self.name

    

class Product(models.Model):
    name = models.CharField(max_length=100)
    unit_price = models.DecimalField(max_digits=10, decimal_places=2)
    gst_percentage = models.DecimalField(max_digits=5, decimal_places=2, default=0) 
    select_scheme = models.CharField(max_length=20, blank=True, null=True)
    free_product = models.ForeignKey('self',on_delete=models.SET_NULL,null=True,blank=True)
    
    def __str__(self):
        return self.name


class Bill(models.Model):
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE)
    bill_date = models.DateTimeField(auto_now_add=True)
    grand_total = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    scheme_discount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    redeem_points = models.IntegerField(default=0)
    balance_due = models.DecimalField(max_digits=10, decimal_places=2, default=0)   
    net_payable = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    earned_points = models.DecimalField(max_digits=10, decimal_places=2, default=0)   
    created_at = models.DateTimeField(default=timezone.now) 
    scheme_label = models.CharField(max_length=100, default="") 
    

class BillItem(models.Model):
    bill = models.ForeignKey(Bill, on_delete=models.CASCADE, related_name="items")
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.IntegerField()   
    price = models.DecimalField(max_digits=10, decimal_places=2)
    gst_percentage = models.DecimalField(max_digits=5, decimal_places=2) 
    subtotal = models.DecimalField(max_digits=10, decimal_places=2)

   
