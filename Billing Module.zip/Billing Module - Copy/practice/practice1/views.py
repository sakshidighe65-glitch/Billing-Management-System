import json

from django.shortcuts import render, redirect, get_object_or_404
from django.http import JsonResponse
from django.contrib import messages
from django.db.models import Q
from django.utils import timezone

from .models import Customer, Product, Bill, BillItem

from decimal import Decimal


def verify_bill(request):
    data = json.loads(request.body)

    items = data.get("items", [])
    redeem_points = int(data.get("redeem_points", 0))
    balance_due = Decimal(str(data.get("balance_due", "0")))
    old_balance = Decimal(str(data.get("old_balance", "0")))

    subtotal = Decimal("0")

    for item in items:
        price = Decimal(str(item["price"]))
        qty = int(item["qty"])
        gst = Decimal(str(item["gst"]))

        sub = price * qty
        sub += sub * (gst / Decimal("100"))
        subtotal += sub

    # Discount logic
    discount = Decimal("0")

    if subtotal > Decimal("10000"):
        discount = subtotal * Decimal("0.10")

    total_after_discount = subtotal - discount

    # Redeem value logic
    if redeem_points <= 100:
        redeem_value = Decimal(redeem_points) * Decimal("100")
    else:
        first_hundred_value = Decimal("100") * Decimal("100")
        remaining_points = Decimal(redeem_points - 100)
        redeem_value = (
            first_hundred_value
            + (remaining_points * Decimal("200"))
        )

    if redeem_value > total_after_discount:
        redeem_value = total_after_discount

    # Net payable logic
    net_payable = (
        total_after_discount
        - redeem_value
        - balance_due
        + old_balance
    )

    if net_payable < 0:
        net_payable = Decimal("0")

    return JsonResponse({
        "subtotal": float(subtotal),
        "discount": float(discount),
        "redeem_value": float(redeem_value),
        "net_payable": float(net_payable),
    })


def add_product(request):
    if request.method == "POST":

        print(request.POST)

        name = request.POST.get("name")
        unit_price = request.POST.get("unit_price")
        gst_percentage = request.POST.get("gst_percentage")
        scheme = request.POST.get("select_scheme")
        free_product_id = request.POST.get("free_product")

        print("Name:", name)
        print("Unit Price:", unit_price)
        print("GST:", gst_percentage)
        print("Scheme:", scheme)
        print("Free Product ID:", free_product_id)

        # Free product select केला असेल तर Product object मिळवा
        free_product = None

        if free_product_id:
            free_product = Product.objects.get(id=free_product_id)

        product = Product(
            name=name,
            unit_price=unit_price,
            gst_percentage=gst_percentage,
            select_scheme=scheme,
            free_product=free_product,
        )

        product.save()

        print("Saved Successfully")

        return redirect("add_product")

    products = Product.objects.all()

    return render(
        request,
        "add_product.html",
        {"products": products}
    )


def get_customer(request, customer_id):
    try:
        customer = Customer.objects.get(id=customer_id)

        return JsonResponse({
            "name": customer.name,
            "contact": customer.contact,
            "balance_due": float(customer.balance_due or 0),
            "loyalty_points": float(customer.loyalty_points or 0),
            "total_visits": int(customer.total_visits or 0),
            })

    except Customer.DoesNotExist:
        return JsonResponse(
            {"error": "Customer not found"},
            status=404
        )


def billing_page(request):

    if request.method == "POST":

        customer_id = request.POST.get("customer_id")
        customer_name = request.POST.get("customer_name")
        customer_contact = request.POST.get("customer_contact")

        balance_due_input = Decimal(
            request.POST.get("balance_due") or "0"
        )

        redeem_points = int(
            request.POST.get("redeem_points") or 0
        )

        is_old_customer = False
        customer = None

        # -------------------------------------------------
        # Customer fetch / create
        # -------------------------------------------------

        if customer_id:

            try:
                customer = Customer.objects.get(
                    id=customer_id
                )

                is_old_customer = True

            except Customer.DoesNotExist:

                messages.error(
                    request,
                    "Customer not found."
                )

                return redirect("billing_page")

        elif customer_name and customer_contact:

            customer = Customer.objects.filter(
                Q(name=customer_name)
                | Q(contact=customer_contact)
            ).first()

            if not customer:

                customer = Customer.objects.create(
                    name=customer_name,
                    contact=customer_contact,
                    balance_due=balance_due_input,
                    loyalty_points=0,
                    total_visits=0,
                )

            else:

                is_old_customer = True

        # -------------------------------------------------
        # Products
        # -------------------------------------------------

        product_ids = request.POST.getlist("product")
        quantities = request.POST.getlist("qty")
        prices = request.POST.getlist("price")

        raw_grand_total = Decimal("0")

        items_to_create = []

        for i in range(len(product_ids)):

            if product_ids[i]:

                try:

                    product_obj = Product.objects.get(
                        id=product_ids[i]
                    )

                    qty = int(
                        quantities[i] or 1
                    )

                    price = Decimal(
                        prices[i] or "0"
                    )

                    gst = Decimal(
                        product_obj.gst_percentage or "0"
                    )

                    item_subtotal = price * qty

                    item_subtotal += (
                        item_subtotal
                        * (gst / Decimal("100"))
                    )

                    raw_grand_total += item_subtotal

                    items_to_create.append({
                        "product_obj": product_obj,
                        "qty": qty,
                        "price": price,
                        "gst": gst,
                        "subtotal": item_subtotal,
                    })

                except Product.DoesNotExist:
                    continue

        # -------------------------------------------------
        # Scheme discount
        # -------------------------------------------------

        discount = Decimal("0")

        scheme_label = "No Scheme"

        visits = getattr(
            customer,
            "total_visits",
            0
        ) or 0

        if visits > 10:

            discount = (
                raw_grand_total
                * Decimal("0.12")
            )

            scheme_label = "12% Scheme"

        elif 6 <= visits <= 10:

            discount = (
                raw_grand_total
                * Decimal("0.10")
            )

            scheme_label = "10% Scheme"

        elif 4 <= visits <= 5:

            discount = (
                raw_grand_total
                * Decimal("0.05")
            )

            scheme_label = "5% Scheme"

        elif 1 <= visits <= 2:

            if raw_grand_total >= Decimal("10000"):

                discount = (
                    raw_grand_total
                    * Decimal("0.10")
                )

                scheme_label = "10% Scheme"

            else:

                discount = Decimal("0")

                scheme_label = "No Scheme"

        else:

            discount = Decimal("0")

            scheme_label = "No Scheme"

        total_after_discount = (
            raw_grand_total - discount
        )

        # -------------------------------------------------
        # Redeem validation
        # -------------------------------------------------

        if customer is not None:

            if redeem_points > customer.loyalty_points:

                messages.error(
                    request,
                    f"Redeem points exceed available loyalty "
                    f"({customer.loyalty_points})"
                )

                return redirect("billing_page")

        # -------------------------------------------------
        # Redeem value
        # 1 Point = ₹100
        # -------------------------------------------------

        redeem_value = (
            Decimal(redeem_points)
            * Decimal("100")
        )

        if redeem_value > total_after_discount:

            redeem_value = total_after_discount

        # -------------------------------------------------
        # Final Net Payable
        # -------------------------------------------------

        if is_old_customer:

            final_net_payable = max(
                Decimal("0"),
                total_after_discount
                - redeem_value
                - balance_due_input
                + customer.balance_due
            )

        else:

            final_net_payable = max(
                Decimal("0"),
                total_after_discount
                - redeem_value
                - balance_due_input
            )

        # -------------------------------------------------
        # Earned Points
        # -------------------------------------------------

        if final_net_payable <= Decimal("10000"):

            earned_points = (
                final_net_payable
                / Decimal("100")
            )

        else:

            first_slab_points = Decimal("100")

            remaining_amount = (
                final_net_payable
                - Decimal("10000")
            )

            second_slab_points = (
                remaining_amount
                / Decimal("200")
            )

            earned_points = (
                first_slab_points
                + second_slab_points
            )

        # -------------------------------------------------
        # Create Bill
        # -------------------------------------------------

        bill = Bill.objects.create(
            customer=customer,
            redeem_points=redeem_points,
            grand_total=raw_grand_total,
            scheme_discount=discount,
            net_payable=final_net_payable,
            balance_due=balance_due_input,
            earned_points=earned_points,
            scheme_label=scheme_label,
        )

        # -------------------------------------------------
        # Create Bill Items
        # -------------------------------------------------

        for item in items_to_create:

            BillItem.objects.create(
                bill=bill,
                product=item["product_obj"],
                quantity=item["qty"],
                price=item["price"],
                gst_percentage=item["gst"],
                subtotal=item["subtotal"],
            )

        # -------------------------------------------------
        # Loyalty Points + Visits Update
        # -------------------------------------------------

        if customer:

            available_points = max(
                0,
                customer.loyalty_points - redeem_points
            )

            customer.loyalty_points = (
                available_points + earned_points
            )

            # Old customer
            if is_old_customer:

                customer.balance_due = max(
                    Decimal("0"),
                    customer.balance_due - balance_due_input
                )

                customer.total_visits = (
                    customer.total_visits + 1
                )

            # New customer
            else:

                customer.balance_due = (
                    balance_due_input
                )

                customer.total_visits = 1

            customer.save()

            print(
                f"Customer {customer.name} updated: "
                f"loyalty_points={customer.loyalty_points}, "
                f"balance_due={customer.balance_due}, "
                f"total_visits={customer.total_visits}, "
                f"earned_points={earned_points}"
            )

        return redirect("billing_page")

    # -------------------------------------------------
    # GET
    # -------------------------------------------------

    customers = Customer.objects.all()

    products = Product.objects.select_related('free_product').all()

    return render(
        request,
        "billing.html",
        {
            "customers": customers,
            "products": products,
        }
    )


def product_list(request):

    products = Product.objects.all()

    return render(
        request,
        "product_list.html",
        {"products": products}
    )


def admin_panel(request):

    products = Product.objects.all()

    context = {
        "products": products,
    }

    return render(
        request,
        "admin_panel.html",
        context
    )


def print_bill(request):
    selected_date = request.GET.get("date")

    customers = Customer.objects.all()

    if selected_date:
        customers = Customer.objects.filter(
            bill__bill_date__date=selected_date
        ).distinct()

    return render(request, "print_bill.html", {
        "customers": customers,
        "selected_date": selected_date,
    })


def view_bill(request, customer_id):

    customer = get_object_or_404(
        Customer,
        id=customer_id
    )

    bills = Bill.objects.filter(
        customer=customer
    ).order_by("-bill_date")

    return render(
        request,
        "view_bill.html",
        {
            "customer": customer,
            "bills": bills,
        }
    )