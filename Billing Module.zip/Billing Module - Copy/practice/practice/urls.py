"""
URL configuration for practice project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/6.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.urls import path
from practice1 import views


urlpatterns = [
    path('billing/', views.billing_page, name='billing_page'),
    path('add_product/', views.add_product, name='add_product'),
    path('verify-bill/', views.verify_bill, name='verify_bill'),
    path('admin_panel/', views.admin_panel, name='admin_panel'),
    path("get_customer/<int:customer_id>/", views.get_customer, name="get_customer"),
    path("", views.product_list, name="product_list"),
    path("print_bill/", views.print_bill, name="print_bill"),
    path("view_bill/<int:customer_id>/", views.view_bill, name="view_bill"),
]
